
import MarketingPreferencesComponent from "@/components/MarketingPreferencesComponent";
export default function page() 
{
  return <MarketingPreferencesComponent />
}
