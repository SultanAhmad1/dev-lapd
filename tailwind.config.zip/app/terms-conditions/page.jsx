"use client"

import TermsConditionComponent from "@/components/TermsConditionComponent"

export default function page() 
{
  return <TermsConditionComponent />
}
