import ContactComponent from "@/components/ContactComponent";
import { redirect } from "next/navigation";

export default function page() 
{
  redirect('/');
  return <ContactComponent />
}
