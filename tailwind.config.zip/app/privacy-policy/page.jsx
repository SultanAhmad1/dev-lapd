import PrivacyComponent from "@/components/PrivacyComponent";

export default function page() 
{
    
  return <PrivacyComponent />
}
