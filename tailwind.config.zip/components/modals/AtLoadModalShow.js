"use client";
import SubAtLoadLoadShow from "./subcomponents/SubAtLoadLoadShow"

function AtLoadModalShow() 
{
    return (
        <SubAtLoadLoadShow/>
    )
}

export default AtLoadModalShow