"use client";

function availableStoresShow() {
  return (
    <div>availableStoresShow</div>
  )
}

export default availableStoresShow