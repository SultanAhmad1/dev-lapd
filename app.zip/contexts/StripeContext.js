"use client";
import { createContext } from "react";

const StripeContext = createContext()

export default  StripeContext