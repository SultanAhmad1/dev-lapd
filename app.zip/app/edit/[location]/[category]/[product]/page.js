import React from 'react'

function productEdit({params})  
{
  return (
    <div>Edit product</div>
  )
}

export default productEdit