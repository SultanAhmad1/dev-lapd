"use client";
function Layout({ children }) 
{
  return (
    <>
      {children}
    </>
  )
}

export default Layout