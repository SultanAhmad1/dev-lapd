"use client";
import React from "react";

const BannerFooterLogo = () => {
  return <div>BannerFooterLogo</div>;
};

export default BannerFooterLogo;
