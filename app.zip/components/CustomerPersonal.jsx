"use client";
import CustomerPersonCom from "./customerPersonComp/CustomerPersonCom";

export default function CustomerPersonal() 
{
  return (
   <CustomerPersonCom />
  );
}
